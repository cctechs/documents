#!/usr/bin/python3
#encoding=utf-8

if __name__ == "__main__":
    zhangsan = input("张三请输入 1:剪刀 2:石头 3:布\n")
    lisi = input("李四请输入 1:剪刀 2:石头 3:布\n")

    if lisi > zhangsan:
        print("李四 赢")
    elif lisi < zhangsan:
        print("张三 赢")
    else:
        print("一样")
