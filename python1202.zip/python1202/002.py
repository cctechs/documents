#!/usr/bin/python3
# encoding=utf-8

list1 = [2989, 435, 67, 2, 5, 7, 8, 78, 9, 3]

sum = 0
for i in list1:
    sum = sum + i
print("sum=%d"%sum)
        